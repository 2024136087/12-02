import 'package:bamtol_market_app/main.dart';
import 'package:bamtol_market_app/src/init/page/init_start_page.dart';
import 'package:bamtol_market_app/src/init/page/splash.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class InitStartPage extends StatelessWidget {
  const InitStartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 99,
              height: 116,
              child: Image.asset('assets/images/logo_simbol.png'),
            ),
          ],
        ),
      ),
    );
  }
}

@override
Widget build(BuildContext context) {
  return Scaffold(
    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 99,
            height: 116,
            child: Image.asset('assets/images/logo_simbol.png'),
          ),
          const SizedBox(height: 40),
          Text(
            '당신 근처의 밤톨마켓',
            style: GoogleFonts.notoSans(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 15),
          Text(
            '중고 거래부터 동네 정보까지, \n지금 내 동네를 선택하고 시작해보게요!',
            textAlign: TextAlign.center,
            style: GoogleFonts.notoSans(
              fontSize: 18,
              color: Colors.white.withOpacity(0.6),
            ),
          ),
        ],
      ),
    ),
  );
}

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  late bool isInitStarted;

  @override
  void initState() {
    super.initState();
    isInitStarted = prefs.getBool('isInitStarted') ?? true;
  }

  @override
  Widget build(BuildContext context) {
    return isInitStarted ? const InitStartPage() : const SplashPage();
  }
}
